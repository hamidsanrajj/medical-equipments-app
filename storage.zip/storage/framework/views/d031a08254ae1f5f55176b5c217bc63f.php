
<?php $__env->startSection('title','- Security Equipments'); ?>
<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/views/pages/security_equipments.blade.php ENDPATH**/ ?>