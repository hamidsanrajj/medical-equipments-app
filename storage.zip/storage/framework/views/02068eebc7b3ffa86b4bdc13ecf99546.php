    <!-- slider section -->
    <section class="slider_section ">
      <div class="container ">
        <div class="row">
          <div class="col-md-6 ">
            <div class="detail-box">
              <h1>
                Repair and <br>
                Maintenance <br>
                Services
              </h1>
              <p>
                We provide repair and maintenance services at affordable prices. we have experts for repair and maintenance work at your door step. Every issue can be resolved on an instant basis with inance
              </p>
              <a href="#contact">
                Contact Us
              </a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="img-box">
              <img src="images/slider-img.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div><?php /**PATH C:\xampp\htdocs\inance\resources\views/include/slider.blade.php ENDPATH**/ ?>