
<?php $__env->startSection('title','- Home Appliances'); ?>
<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/views/pages/home_appliances.blade.php ENDPATH**/ ?>