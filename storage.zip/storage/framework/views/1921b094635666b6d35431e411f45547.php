

<?php $__env->startSection('title','- How It Works'); ?>

<?php $__env->startSection('content'); ?>

<div class="how-it-works">
    <div class="row" style="padding: 100px;">
        <div class="col-md-5">
            <h1 class="mb-4" style="font-size: 50px; color: darkblue;">How it Works</h1>
            <h2 class="mb-4">Discover 350,000+ Vehicles for Sale In All Conditions</h2>
            <p>E-Auction connects buying Members and sellers of all types of vehicles in all conditions through our 100% online auction platform. You’ll also find tools to check out, bid on, pay for, and receive the vehicles that meet your needs.</p>
            <p>We hold regular auctions at our 220 + Locations in 11 countries, and national spotlight auctions that make it easy to find a specific type of vehicle.</p>
        </div>   
        <div class="col-md-1"></div>
        <div class="col-md-6">
            <img src="assets/img/how-it-works-collage2.png">
        </div>  
    </div>
    <div class="row" style="padding: 100px; padding-top: 0px;">
        <div class="col-md-6">
            <img src="assets/img/get-started.jpg">
        </div>  
        <div class="col-md-1"></div>
        <div class="col-md-5">
            <h1 class="mb-4" style="font-size: 50px; color: darkblue;">Get Started</h1>
            <p>Register for an account, then purchase a Basic or Premier Membership. You can get a full refund for up to seven days if you change your mind as long as you don’t use your Member benefits*, so it’s risk free.</p>
            <a href="#" class="btn btn-primary" style="border-radius: 30px; padding: 15px; font-weight: bold;">Register Now</a>
        </div>   
    </div>
</div>

<style>
    .steps-registration .col-md-4{
        padding-right: 50px;
    }

    .steps-registration .col-md-4 p{
        margin-top: 10px;
    }

    .steps-registration .col-md-4 img{
        margin-bottom: 10px;
    }
</style>
<div class="steps-registration">
    <div class="row" style="padding: 100px; padding-top: 0px;">
    <h1 style="font-size: 50px; color: darkblue; margin-bottom: 100px;">After Registration</h1>
        <!-- <hr style="border: 3px solid black; width: 120px; margin-left: 10px;"> -->
            <div class="col-md-4">
                <div><img src="assets/img/upload-licenses.svg"></div>
                <b>Upload License(s)</b>
                <p>Scan a government-issued ID and upload any business licenses required in states where you want to buy vehicles.</p>
            </div>
        <div class="col-md-4">
                <div><img src="assets/img/license.svg"></div>
                <b>No License Is No Problem</b>
                <p>If you don’t have a dealer’s license or other required credentials to buy a vehicle in a specific state, search for No License Required vehicles or work with a Broker.</p></div>
        <div class="col-md-4">
            <div><img src="assets/img/search-and-save.svg"></div>
                <b>Search, Save & Set Alerts</b>
                <p>Search & filter our huge selection to find the vehicles that fit your needs. Save your common searches.</p><p>Track vehicles you add to your Watchlist, and set Vehicle Alerts to know when new vehicles you want are listed.</p></div>
        <div class="row" style="margin-top: 50px;">
            <div class="col-md-4">
                <div><img src="assets/img/join-auctions.svg"></div>
                <b>Join Auctions</b>
                <p>
                    Join the fun and action of our live auctions under the options in the Auctions tab, likes Today’s Auctions, Auction Calendar and the Join An Auction.
                </p>        
            </div>
            <div class="col-md-4">
                <div><img src="assets/img/laptop-credit.svg"></div>
                <b>Other Ways to Win</b>
                <p>
                    Set a Max Bid and our system will incrementally bid for you up to your top price. Purchase Buy It Now vehicles for the asking price or make counteroffers with the Make An Offer function.
                </p>        
            </div>
            <div class="col-md-4">
                <div><img src="assets/img/get-it-delivered.svg"></div>
                <b>Receive Your Vehicles</b>
                <p>
                    Order delivery through E-Auction, dispatch your own transporter, or pick vehicles up in person.
                </p>        
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction ---\resources\views/include/views/pages/how-it-works.blade.php ENDPATH**/ ?>