
<?php $__env->startSection('title','- Contact'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row" style="margin-top: 50px;">
        <div class="col-md-3">

        </div>
        <div class="col-md-6">
            <h1 class="text-center mb-4">Contact</h1>
            <form action="<?php echo e(url('/')); ?>/contact-query" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-4">
                    <label>Name</label>
                    <input class="form-control" name="name" type="text" required>
                </div>
                <div class="form-group mt-4">
                    <label>Email</label>
                    <input class="form-control" name="email" type="email" required>
                </div>
                <div class="form-group mt-4">
                    <label>Phone</label>
                    <input class="form-control" name="phone" type="number" required>
                </div>
                <div class="form-group mt-4">
                    <label>Message</label>
                    <textarea col="4" row="5" name="message" class="form-control"></textarea>
                </div>
                <div class="form-group mt-4">
                    <input class="btn btn-primary" name="submit" type="submit">
                </div>
            </form>
        </div>
        <div class="col-md-3">

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/views/pages/contact.blade.php ENDPATH**/ ?>