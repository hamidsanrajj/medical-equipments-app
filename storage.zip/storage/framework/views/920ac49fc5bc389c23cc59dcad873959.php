


<?php $__env->startSection('title','- Detail'); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="assets/css/detail.css">


<car-detail>
    <div class="detail">
        <div class="row">
            <div class="col-md-6">

<section>
    <div class="container">
        <div class="carousel">
            <input type="radio" name="slides" checked="checked" id="slide-1">
            <input type="radio" name="slides" id="slide-2">
            <input type="radio" name="slides" id="slide-3">
            <input type="radio" name="slides" id="slide-4">
            <input type="radio" name="slides" id="slide-5">
            <input type="radio" name="slides" id="slide-6">
            <ul class="carousel__slides">
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Tim Marshall</span>
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Christian Joudrey</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Steve Carter</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Aleksandra Boguslawska</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Rosan Harmens</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                        </div>
                        <figcaption>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            <span class="credit">Photo: Annie Spratt</span>                            
                        </figcaption>
                    </figure>
                </li>
            </ul>    
            <ul class="carousel__thumbnails">
                <li>
                    <label for="slide-1"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
                <li>
                    <label for="slide-2"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
                <li>
                    <label for="slide-3"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
                <li>
                    <label for="slide-4"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
                <li>
                    <label for="slide-5"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
                <li>
                    <label for="slide-6"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                </li>
            </ul>
        </div>
    </div>
</section>

<!--            <shipping>
                <div class="shippingEstimate row" style="border: 1px solid lightgray; margin: 20px; border-radius: 5px;">
                    <h3>Shipping Estimate</h3>

                </div>
            </shipping> -->

                <form>
                    
                </form>



                <div class="row" style="padding: 20px;">


                <?php if(isset($rs)): ?>
                        <!-- <?php echo e(Session::get('username')); ?> -->
                        <div class="col-md-6">
                            <a href="<?php echo e(route('bid')); ?>" class="form-control btn btn-warning">Place Bid</a>
                        </div>
                        <div class="col-md-6">
                            <a href="#" class="form-control btn btn-success">Add to Favorites</a>
                        </div>
                <?php else: ?>
                        <div class="col-md-6">
                            <a href="<?php echo e(route('login')); ?>" class="form-control btn btn-warning">Place Bid</a>
                        </div>
                        <div class="col-md-6">
                            <a href="#" class="form-control btn btn-success">Add to Favorites</a>
                        </div>
                <?php endif; ?>

                    
                </div>


            </div>


<style type="text/css">
    .labelItem{
        border-bottom: 1px solid #f7f7f7; padding: 10px;
    }
    .vehicleDetails{
        border: 1px solid lightgray; border-radius: 10px;
    }
    .vehicleDetailsHeading{
        padding: 20px; border-bottom: 1px solid #f7f7f7; font-weight: bold;
    }

    .vehicleDetailsVal{
        font-weight: bold;
    }
</style>

            <!-- <div class="col-md-4"></div> -->
            <div class="col-md-6 vehicleDetails"><div class="vehicleDetailsHeading"> <h4>Vehicle Details </h4> </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Lot number:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>55428225</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>VIN:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>WA1MMDFE5ED******</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Odometer:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>253,487 km (ACTUAL)</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Primary damage:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>MECHANICAL</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6 ">
                        <div>Estimated retail value:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>$16,000.00 CAD</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Cylinders:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>6</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Body style:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>4DR SPOR</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Color:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>GRAY</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Engine type:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>3.0L 6</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Transmission:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>AUTOMATIC</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Drive:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>All wheel drive</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Vehicle type:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>AUTOMOBILE</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Fuel:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>DIESEL</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Keys:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>YES</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Highlights:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>Run and Drive</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</car-detail>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction\resources\views//include/views/detail.blade.php ENDPATH**/ ?>