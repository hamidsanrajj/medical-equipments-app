<div id="header" class="header">
	<div class="heading">
	<h1>ZHR International</h1><sub>Repair and Sell Medical Machines</sub>
	</div>

<link rel="stylesheet" type="text/css" href="assets/css/header.css">

    
<nav class="navbar navbar-expand-lg bg-primary navbar-dark bg-primary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('home')); ?>">About</a>
        </li> -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="<?php echo e(route('home')); ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Medical Devices
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('x-ray')); ?>">X-Ray Machine</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('ct-scan')); ?>">CT Scan Machine</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('bloodTesting')); ?>">Blood Testing Machine</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('ultrasonicTherapy')); ?>">Ultrasonic Therapy Apparatus</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('oec')); ?>">OEC Elite | GE HealthCare</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('laserscope')); ?>">Laserscope</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('agfaDryStar')); ?>">AGFA Drystar 5500</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('agfa-35x')); ?>">AGFA 35-X</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('agfaCRDigitizer')); ?>">AGFA DX-G CR Digitizer</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('OtTable')); ?>">Electric OT Table</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('ultrasound')); ?>">Ultrasound Machine</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('surgicalCautery')); ?>">Surgical Cautery</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('ventilator')); ?>">Ventilator Machine</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('colposcopy')); ?>">Colposcopy</a></li>
          </ul>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('x-ray')); ?>">X-Ray Machine</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('ct-scan')); ?>">CT Scan Machine</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('bloodTesting')); ?>">Blood Testing Machine</a>
        </li>


        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('ventilator')); ?>">Ventilator Machine</a>
        </li>


        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('ventilator')); ?>">Ultrasound Machine</a>
        </li>
        <!-- <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="<?php echo e(route('homeAppliances')); ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Home Appliances
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('homeAppliances')); ?>">Refrigerator</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('homeAppliances')); ?>">Television</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('homeAppliances')); ?>">Air Conditioner</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('homeAppliances')); ?>">Microwave Oven</a></li>       
            <li><a class="dropdown-item" href="<?php echo e(route('homeAppliances')); ?>">Telephone</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="<?php echo e(route('smartDevices')); ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Smart Devices
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('smartDevices')); ?>">Mobile</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('smartDevices')); ?>">Tablets</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="<?php echo e(route('securityEquipments')); ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Security Equipments
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('securityEquipments')); ?>">Metal Detector</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="<?php echo e(route('computerDevices')); ?>" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Computer Devices
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('computerDevices')); ?>">PC</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('computerDevices')); ?>">Laptop</a></li>           
            <li><a class="dropdown-item" href="<?php echo e(route('computerDevices')); ?>">Printer</a></li>
          </ul>
        </li> -->
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit" style="color: white; border: 1px solid white;">Search</button>
      </form>
    </div>
  </div>
</nav>
</div><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/header.blade.php ENDPATH**/ ?>