<product class="product">
<h2 class="headingProduct">Today's Auction</h2>
<div class="owl-carousel owl-theme">
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName1" class="card-title"></h5>
    <p id="carLot1" class="card-text"></p>
    <p id="carCurrentBid1" class="card-text"></p>
    <p id="carLocation1" class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName2" class="card-title"></h5>
    <p id="carLot2" class="card-text"></p>
    <p id="carCurrentBid2" class="card-text"></p>
    <p id="carLocation2" class="card-text"></p>
    <p class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName3" class="card-title"></h5>
    <p id="carLot3" class="card-text"></p>
    <p id="carCurrentBid3" class="card-text"></p>
    <p id="carLocation3" class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName4" class="card-title"></h5>
    <p id="carLot4" class="card-text"></p>
    <p id="carCurrentBid4" class="card-text"></p>
    <p id="carLocation4" class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName5" class="card-title"></h5>
    <p id="carLot5" class="card-text"></p>
    <p id="carCurrentBid5" class="card-text"></p>
    <p id="carLocation5" class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
<div class="item">
<div class="card">
  <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 id="carName6" class="card-title"></h5>
    <p id="carLot6" class="card-text"></p>
    <p id="carCurrentBid6" class="card-text"></p>
    <p id="carLocation6" class="card-text"></p>
    <a href="<?php echo e(route('detail')); ?>" class="btn btn-primary">Detail</a>
    <a href="<?php echo e(route('bid')); ?>" class="btn btn-success">Bid</a>
  </div>
</div>
</div>
</div>

<script>
  $(document).ready(function() {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
      margin: 10,
      nav: true,
      loop: true,
      autoplay:true,
      autoplayTimeout:3000,
      //autoplayHoverPause:true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 4
        }
      }
    })
  })
</script>


<script>
const txt1 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552233", "bid":"Current Bid: $250 CAD", "loc":"Location: Texas"}'
const obj1 = JSON.parse(txt1);
document.getElementById("carName1").innerHTML = obj1.name;
document.getElementById("carLot1").innerHTML = obj1.lot;
document.getElementById("carCurrentBid1").innerHTML = obj1.bid;
document.getElementById("carLocation1").innerHTML = obj1.loc;

const txt2 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552234", "bid":"Current Bid: $150 CAD", "loc":"Location: Texas"}'
const obj2 = JSON.parse(txt2);
document.getElementById("carName2").innerHTML = obj2.name;
document.getElementById("carLot2").innerHTML = obj2.lot;
document.getElementById("carCurrentBid2").innerHTML = obj2.bid;
document.getElementById("carLocation2").innerHTML = obj2.loc;

const txt3 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552235", "bid":"Current Bid: $350 CAD", "loc":"Location: Texas"}'
const obj3 = JSON.parse(txt3);
document.getElementById("carName3").innerHTML = obj3.name;
document.getElementById("carLot3").innerHTML = obj3.lot;
document.getElementById("carCurrentBid3").innerHTML = obj3.bid;
document.getElementById("carLocation3").innerHTML = obj3.loc;

const txt4 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552236", "bid":"Current Bid: $550 CAD", "loc":"Location: Texas"}'
const obj4 = JSON.parse(txt4);
document.getElementById("carName4").innerHTML = obj4.name;
document.getElementById("carLot4").innerHTML = obj4.lot;
document.getElementById("carCurrentBid4").innerHTML = obj4.bid;
document.getElementById("carLocation4").innerHTML = obj4.loc;

const txt5 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552237", "bid":"Current Bid: $650 CAD", "loc":"Location: Texas"}'
const obj5 = JSON.parse(txt5);
document.getElementById("carName5").innerHTML = obj5.name;
document.getElementById("carLot5").innerHTML = obj5.lot;
document.getElementById("carCurrentBid5").innerHTML = obj5.bid;
document.getElementById("carLocation5").innerHTML = obj5.loc;

const txt6 = '{"name":"2014 AUDI Q7 PREMIUM PLUS", "age":30, "lot":"Lot# 552238", "bid":"Current Bid: $450 CAD", "loc":"Location: Texas"}'
const obj6 = JSON.parse(txt6);
document.getElementById("carName6").innerHTML = obj6.name;
document.getElementById("carLot6").innerHTML = obj6.lot;
document.getElementById("carCurrentBid6").innerHTML = obj6.bid;
document.getElementById("carLocation6").innerHTML = obj6.loc;
</script>

</product><?php /**PATH C:\xampp\htdocs\auction ---\resources\views/include/main.blade.php ENDPATH**/ ?>