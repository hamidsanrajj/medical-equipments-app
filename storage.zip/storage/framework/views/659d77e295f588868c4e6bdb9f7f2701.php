
<footer class="bg-light footer" style="">
    <div class="footer row">
        <div class="col-md-4">
            <h1>E-Auction</h1>
            <sub class="subHeadingFooter" style="">Repairable and Used Cars</sub>
        </div>
        <div class="col-md-4">
            <h3>Info Links</h3>
            <ul style="">
                <li> <a href="">How it works</a> </li>
                <li> <a href="">Auction</a> </li>
                <li> <a href="">Locations</a> </li>
                <li> <a href="">Services & Support</a> </li>
                <li> <a href="">Help Center</a> </li>
            </ul>
        </div>
        <div class="col-md-4">
            <h3 class="socialMedia">Social Media</h3>
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-linkedin"></a>
            <a href="#" class="fa fa-youtube"></a>
            <a href="#" class="fa fa-instagram"></a>
        </div>
    </div>
</footer>

</body>
    <script src="assets/owl/docs/assets/vendors/highlight.js"></script>
    <script src="assets/owl/docs/assets/js/app.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html><?php /**PATH C:\xampp\htdocs\auction ---\resources\views/include/footer.blade.php ENDPATH**/ ?>