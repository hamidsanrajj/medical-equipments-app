<banner>
    <div class="banner">
    </div>
</banner>
<?php /**PATH C:\xampp\htdocs\auction\resources\views/include/banner.blade.php ENDPATH**/ ?>