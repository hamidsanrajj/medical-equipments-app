</div>
</body>
<script type="text/javascript" src="assets/css/bootstrap-5.0.2-dist/js/bootstrap.bundle.js"></script>
<script type="text/javascript" src="assets/js/js.js"></script>
</html>
<?php /**PATH C:\xampp\htdocs\abcLense\resources\views////layouts/include/footer.blade.php ENDPATH**/ ?>