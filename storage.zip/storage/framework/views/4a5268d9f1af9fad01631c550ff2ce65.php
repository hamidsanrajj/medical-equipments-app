
<?php $__env->startSection('title','- Medical Devices'); ?>
<?php $__env->startSection('content'); ?>




<div class="container-box">
    <div class="row">
        <div class="col-md-6">
            <img src="assets/images/AGFA 35-X.jpg" width=500 height= 500>
        </div>
        <div class="col-md-6">

            <table>
                <tr>
                    <td><b>Name</b></td>
                    <td>Agfa 35-x</td>
                </tr>
                <tr>
                    <td><b>Status</b></td>
                    <td style="color: green; font-weight: bold;">Available</td>
                </tr>
                <tr>
                    <td><b>Price</b></td>
                    <td></td>
                </tr>
                <tr>
                    <td><b>Models</b></td>
                    <td>2014-2025</td>
                </tr>
                <tr>
                    <td><b>Parts</b></td>
                    <td>digitizer unit, cassettes, and a workstation</td>
                </tr>
                <tr>
                    <td><b>Types</b></td>
                    <td>three different resolution modes (6, 10, and 20 pixels/mm) and can work with various plate and cassette sizes. </td>
                </tr>
            </table>

            <div class="btn-machine row">
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary form-control">Buy</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-warning form-control">Repair</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-danger form-control">Sell</a>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/views/pages/detail/agfa-35x.blade.php ENDPATH**/ ?>