
<!-- <section id="quote">
  <div class="container">
    <div class="row d-flex justify-content-center align-content-center">
        <button style="background-color: black; color: white; width: 250px; border: 1px solid white; box-shadow: 0px 0px 0px 0px; padding: 20px; margin-bottom: 100px; font-size: 20px; font-weight: bolder;" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Get Quote</button>
    </div>
  </div>
</section> -->

<section id="footer">
<div class="container">
	<div class="row">
    <div class="col-md-4">
      <h1>Gohar Advertiser <br> Expert Printing Signage & Branding Services</h1>
    </div>
    <div class="col-md-4">
      <ul>
        <li><b>Adderss:</b> 17-A Basement, Itehad Centre Blue Area, Islamabad</li>
        <li><b>Phone:</b> +92 312 5117072</li>
        <li><b>Email:</b> goharadvertiser999@gmail.com</li>
      </ul>
    </div>
    <link rel="stylesheet" type="text/css" href="css/social-icons.css">
    <div class="col-md-4 social">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <a href="#" class="fa fa-facebook"></a>
      <a href="#" class="fa fa-instagram"></a>
    </div>
  </div>
</div>

<div class="container copyrights" style=""> 
    &copy; 2025 - All Rights Reserved.
</div>
</section>


	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</body>
</html>




<!-- Modal -->
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="margin-left: 25% !important;">
    <div class="modal-content" style="width:700px; padding-top: 30px !important;">
      <div class="modal-body">
           <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSez2DbRbBvmvicgvhFETj3fA8nOckZ12cjnVBUMyrpM8py1ew/viewform?embedded=true" width="640" height="1100" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
      </div>
      <div class="modal-footer" style="border: 0px;">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div> --><?php /**PATH C:\xampp\htdocs\gohar-advertiser\resources\views/include/footer.blade.php ENDPATH**/ ?>