

<?php $__env->startSection('title','- Bid'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">

  > img {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
  }
}

section {
    background: #F4F4F4;
    padding: 50px 0;
}

.container {
    max-width: 1044px;
    margin: 0 auto;
    padding: 0 20px;
}

.carousel {
    display: block;
    text-align: left;
    position: relative;
    margin-bottom: 22px;
    
    > input {
        clip: rect(1px, 1px, 1px, 1px);
        clip-path: inset(50%);
        height: 1px;
        width: 1px;
        margin: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        
        &:nth-of-type(6):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: -500%; }
        &:nth-of-type(5):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: -400%; }
        &:nth-of-type(4):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: -300%; }
        &:nth-of-type(3):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: -200%; }
        &:nth-of-type(2):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: -100%; }
        &:nth-of-type(1):checked ~ .carousel__slides .carousel__slide:first-of-type { margin-left: 0%; }
        
        &:nth-of-type(1):checked ~ .carousel__thumbnails li:nth-of-type(1) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
        &:nth-of-type(2):checked ~ .carousel__thumbnails li:nth-of-type(2) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
        &:nth-of-type(3):checked ~ .carousel__thumbnails li:nth-of-type(3) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
        &:nth-of-type(4):checked ~ .carousel__thumbnails li:nth-of-type(4) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
        &:nth-of-type(5):checked ~ .carousel__thumbnails li:nth-of-type(5) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
        &:nth-of-type(6):checked ~ .carousel__thumbnails li:nth-of-type(6) { box-shadow: 0px 0px 0px 5px rgba(0,0,255,0.5); }
    }
}

.carousel__slides {
    position: relative;
    z-index: 1;
    padding: 0;
    margin: 0;
    overflow: hidden;
    white-space: nowrap;
    box-sizing: border-box;
    display: flex;
}

.carousel__slide {
    position: relative;
    display: block;
    flex: 1 0 100%;
    width: 100%;
    height: 100%;
    overflow: hidden;
    transition: all 300ms ease-out;
    vertical-align: top;
    box-sizing: border-box;
    white-space: normal;
    
    figure {
        display: flex;
        margin: 0;
    }
    
    div {
        width: 100%;
    }
    
    img {
        display: block;
        flex: 1 1 auto;
        object-fit: cover;
    }
    
    figcaption {
        align-self: flex-end;
        padding: 20px 20px 0 20px;
        flex: 0 0 auto;
        width: 25%;
        min-width: 150px;
    }
    
    .credit {
        margin-top: 1rem;
        color: rgba(0, 0, 0, 0.5);
        display: block;        
    }
    
    &.scrollable {
        overflow-y: scroll;
    }
}

.carousel__thumbnails {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    
    margin: 0 -10px;
    
    .carousel__slides + & {
        margin-top: 20px;
    }
    
    li {        
        flex: 1 1 auto;
        max-width: calc((100% / 6) - 20px);  
        margin: 0 10px;
        transition: all 300ms ease-in-out;
    }
    
    label {
        display: block;
        
                  
        &:hover,
        &:focus {
            cursor: pointer;
            
            img {
                box-shadow: 0px 0px 0px 1px rgba(0,0,0,0.25);
                transition: all 300ms ease-in-out;
            }
        }
    }
    
    img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
}

.detail{
    padding: 50px;
}

.labelItem{
    border-bottom: 1px solid #f7f7f7; padding: 10px;
}

.vehicleBid{
    border: 1px solid lightgray; border-radius: 10px;
}
.vehicleBidHeading{
    padding: 20px; border-bottom: 1px solid #f7f7f7; font-weight: bold;
}

</style>

<car-detail>
    <div class="detail">
        <div class="row">
            <div class="col-md-6 vehicleBid"><div class="vehicleBidHeading"> <h4>Bid Details </h4> </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Total Bids:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>15</div>
                    </div>
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Time Left:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>1D 8H 30M</div>
                    </div>
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Current Bid:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>350 USD</div>
                    </div>
                </div>

                <input type="number" name="" class="form-control mt-4">
                <button class="form-control btn btn-warning mt-2">Bid Now</button>
            
                <hr>

                All bids are legally binding and all sales are final.
                <div class="alerts row mt-2">
                    <h4>Get Alerts on Similar Car</h4>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="First Name">
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="Last Name">
                    </div>
                    <div class="col-md-6 mt-2">
                        <input type="text" class="form-control" placeholder="Email">
                    </div>
                    <div class="col-md-6 mt-2">
                        <input type="text" class="form-control" placeholder="Zip Code">
                    </div>
                    <div class="col-md-12 py-2">
                        <button class="form-control btn btn-primary mt-2">Get Alerts</button>
                    </div>
                </div>

            </div>
            <div class="col-md-6">
                <section>
                    <div class="container">
                        <div class="carousel">
                            <input type="radio" name="slides" checked="checked" id="slide-1">
                            <input type="radio" name="slides" id="slide-2">
                            <input type="radio" name="slides" id="slide-3">
                            <input type="radio" name="slides" id="slide-4">
                            <input type="radio" name="slides" id="slide-5">
                            <input type="radio" name="slides" id="slide-6">
                            <ul class="carousel__slides">
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Tim Marshall</span>
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Christian Joudrey</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Steve Carter</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Aleksandra Boguslawska</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Rosan Harmens</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Annie Spratt</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                            </ul>    
                            <ul class="carousel__thumbnails">
                                <li>
                                    <label for="slide-1"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-2"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-3"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-4"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-5"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-6"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>

                <div class="row" style="padding: 20px;">
                    <div class="col-md-6">
                        <a href="<?php echo e(route('detail')); ?>" class="form-control btn btn-primary">View Detail</a>
                    </div>
                    <div class="col-md-6">
                        <a href="" class="form-control btn btn-success">Add to Favorites</a>
                    </div>
                </div>

            </div>

</div>
</div>
</car-detail>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction ---\resources\views//include/views/bid.blade.php ENDPATH**/ ?>