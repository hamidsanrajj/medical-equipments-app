
<?php $__env->startSection('title','- Medical Devices'); ?>
<?php $__env->startSection('content'); ?>




<div class="container-box">
    <div class="row">
        <div class="col-md-6">
            <img src="assets/images/Electric-OT-Table-1201.jpg" width=500 height= 500>
        </div>
        <div class="col-md-6">

            <table>
                <tr>
                    <td><b>Name</b></td>
                    <td>OT Table</td>
                </tr>
                <tr>
                    <td><b>Status</b></td>
                    <td style="color: green; font-weight: bold;">Available</td>
                </tr>
                <tr>
                    <td><b>Price</b></td>
                    <td></td>
                </tr>
                <tr>
                    <td><b>Models</b></td>
                    <td>2014-2025</td>
                </tr>
                <tr>
                    <td><b>Parts</b></td>
                    <td>a tabletop, a main body, an electric control system, and various accessories. The tabletop is typically divided into sections like head, back, seat, and leg plates, which can be adjusted to various positions during surgery. The electric control system allows for precise adjustments of the table's height, tilting, and other movements. Accessories like head plates, leg supports, and anesthesia screens are used to optimize patient positioning and comfort. </td>
                </tr>
                <tr>
                    <td><b>Types</b></td>
                    <td>general surgery tables, orthopedic tables, and those designed for specialized procedures like C-arm imaging or ophthalmic surgery. </td>
                </tr>
            </table>

            <div class="btn-machine row">
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary form-control">Buy</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-warning form-control">Repair</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-danger form-control">Sell</a>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zhr\resources\views/include/views/pages/detail/OtTable.blade.php ENDPATH**/ ?>