   
      <!--begin::App Main-->
      <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Cars</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Cars</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
              
              <div class="row">

                <form>
                  <div class="row">
                    <h4 class="mt-4 mb-4 fw-bold text-primary">Basic</h4>
                    <div class="col-md-4">
                      <label>Image</label>
                        <input
                        type="file"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>Name</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>Location</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div>  

                  </div>  
                  <div class="row" style="margin-top: 20px;">
                    <h4 class="mt-4 mb-4 text-primary fw-bold">Detail</h4>
                    <div class="col-md-4">
                      <label>Lot Number</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>VIN</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Odometer</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    
                  </div>
                  <div class="row" style="margin-top: 20px;">
                    <div class="col-md-4">
                      <label>Estimate Retail Value</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Cylinders</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Body Style</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                  </div>
                    <div class="row" style="margin-top: 20px;">
                    <div class="col-md-4">
                      <label>Color</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Engine Type</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Transmission</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                  </div>
                    <div class="row" style="margin-top: 20px;">
                    <div class="col-md-4">
                      <label>Drive</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Vehicle Type</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Fuel</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                  </div>
                  <div class="row" style="margin-top: 20px;">
                    <div class="col-md-4">
                      <label>Keys</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

                    <div class="col-md-4">
                      <label>Highlights</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>Primary Damage</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 

<!--                     <div class="col-md-4">
                      <label>Primary Damage</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div>  -->
                  </div>

                  <input type="submit" name="submit" class="btn btn-primary me-2 mt-4 mb-4">
                </form>

              </div>

            <!-- /.row (main row) -->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->
      <!--begin::Footer--><?php /**PATH C:\xampp\htdocs\auction\resources\views//////////admin/admin/dist/pages/include/car.blade.php ENDPATH**/ ?>