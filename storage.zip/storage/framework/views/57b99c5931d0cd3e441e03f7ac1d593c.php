

<link rel="stylesheet" type="text/css" href="assets/css/style.css">

<div class="container products">
	<div class="row">
		<div class="col-md-4">
			<div class="card">
			  <img src="assets/images/x-ray.png" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">X-Ray Machine</h5>
			    <a href="#" class="btn btn-primary">Read More</a>
			  </div>
			</div>	
		</div>
		<div class="col-md-4">
			<div class="card">
			  <img src="assets/images/ct-scan.webp" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">CT Scan Machine</h5>
			    <a href="#" class="btn btn-primary">Read More</a>
			  </div>
			</div>	
		</div>
		<div class="col-md-4">
			<div class="card">
			  <img src="assets/images/blood-test-machine.jpg" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">Blood Testing Machine</h5>
			    <a href="#" class="btn btn-primary">Read More</a>
			  </div>
			</div>	
		</div>
        <div class="col-md-4 gap">
			<div class="card">
			  <img src="assets/images/Ultrasonic-Therapy-Apparatus.jpg" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">Ultrasonic Therapy Apparatus</h5>
			    <a href="#" class="btn btn-primary">Read More</a>
			  </div>
			</div>	
		</div>
		<div class="col-md-4 gap">
			<div class="card">
			  <img src="assets/images/oec-elite-imaging-system-mobile.avif" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">OEC Elite | GE HealthCare</h5>
			    <a href="#" class="btn btn-primary">Read More</a>
			  </div>
			</div>	
		</div>
	</div>
</div>





<?php /**PATH C:\xampp\htdocs\zhr -\resources\views/include/main.blade.php ENDPATH**/ ?>