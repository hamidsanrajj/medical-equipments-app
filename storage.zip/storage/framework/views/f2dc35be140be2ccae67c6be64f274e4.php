

<?php $__env->startSection('title','- Bid'); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="assets/css/bid.css">

<car-detail>
    <div class="detail">
        <div class="row">
            <div class="col-md-6 vehicleBid"><div class="vehicleBidHeading"> <h4>Bid Details </h4> </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Total Bids:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>15</div>
                    </div>
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Time Left:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>1D 8H 30M</div>
                    </div>
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Current Bid:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>350 USD</div>
                    </div>
                </div>

                <input type="number" name="" class="form-control mt-4">
                <button class="form-control btn btn-warning mt-2">Bid Now</button>
            
                <hr>

                All bids are legally binding and all sales are final.
                <div class="alerts row mt-2">
                    <h4>Get Alerts on Similar Car</h4>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="First Name">
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="Last Name">
                    </div>
                    <div class="col-md-6 mt-2">
                        <input type="text" class="form-control" placeholder="Email">
                    </div>
                    <div class="col-md-6 mt-2">
                        <input type="text" class="form-control" placeholder="Zip Code">
                    </div>
                    <div class="col-md-12 py-2">
                        <button class="form-control btn btn-primary mt-2">Get Alerts</button>
                    </div>
                </div>

            </div>
            <div class="col-md-6">
                <section>
                    <div class="container">
                        <div class="carousel">
                            <input type="radio" name="slides" checked="checked" id="slide-1">
                            <input type="radio" name="slides" id="slide-2">
                            <input type="radio" name="slides" id="slide-3">
                            <input type="radio" name="slides" id="slide-4">
                            <input type="radio" name="slides" id="slide-5">
                            <input type="radio" name="slides" id="slide-6">
                            <ul class="carousel__slides">
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Tim Marshall</span>
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Christian Joudrey</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Steve Carter</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Aleksandra Boguslawska</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Rosan Harmens</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                                <li class="carousel__slide">
                                    <figure>
                                        <div>
                                            <img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt="">
                                        </div>
                                        <figcaption>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                            <span class="credit">Photo: Annie Spratt</span>                            
                                        </figcaption>
                                    </figure>
                                </li>
                            </ul>    
                            <ul class="carousel__thumbnails">
                                <li>
                                    <label for="slide-1"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-2"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-3"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-4"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-5"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-6"><img src="https://deinfa.com/wp-content/uploads/2024/06/A-Guide-to-Electric-Cars-in-Pakistan-Featured-Image.png" alt=""></label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>

                <div class="row" style="padding: 20px;">
                    <div class="col-md-6">
                        <a href="<?php echo e(route('detail')); ?>" class="form-control btn btn-primary">View Detail</a>
                    </div>
                    <div class="col-md-6">
                        <a href="" class="form-control btn btn-success">Add to Favorites</a>
                    </div>
                </div>

            </div>

</div>
</div>
</car-detail>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction\resources\views//include/views/bid.blade.php ENDPATH**/ ?>