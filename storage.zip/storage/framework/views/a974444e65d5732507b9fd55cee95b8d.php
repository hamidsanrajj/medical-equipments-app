    <?php echo $__env->make('include/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!--begin::App Wrapper-->
  <div class="app-wrapper">

    <?php echo $__env->make('include/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>

<?php /**PATH C:\xampp\htdocs\auction\resources\views/admin/admin/dist/pages/index.blade.php ENDPATH**/ ?>